package com.example.myapplication.component;

import java.util.List;

public interface OnDetectResultListener {
    void onDetectResult(List<Features> featureList);
}
