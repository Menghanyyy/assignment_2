package com.example.myapplication.database;

public enum ClassType {
    STRING,
    INT,
    EVENT,
    ACTIVITY,
    USER,
    VISIT,
    ACTIVITY_ARRAYLIST,
    USER_ARRAYLIST,
    VISIT_ARRAYLIST,
    EVENT_ARRAYLIST
}
