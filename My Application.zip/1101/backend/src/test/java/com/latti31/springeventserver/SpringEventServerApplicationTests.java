package com.latti31.springeventserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEventServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
